import React from 'react'

const Footer = () => {
    return (
        <>
            <section>
                <footer className="text-center text-white pt-3 pb-3 shadow-lg" style={{ backgroundColor: 'blueviolet' }}>
                    © 2023 - Interview Assignment
                </footer>
            </section>
        </>
    )
}

export default Footer