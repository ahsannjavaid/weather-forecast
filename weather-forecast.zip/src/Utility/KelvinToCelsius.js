export function KelvinToCelsius(temperature) {
    return Math.round(temperature - 273.15);
}